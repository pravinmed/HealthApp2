import React from "react";
import SplitButton from "react-bootstrap/lib/SplitButton";
import ButtonToolbar from "react-bootstrap/lib/ButtonToolbar";
import DropdownButton from "react-bootstrap/lib/DropdownButton";
import MenuItem from "react-bootstrap/lib/MenuItem";

export default class LocationList extends React.Component {
 
 index =0;

 constructor(props)
 {
  super(props);
   this.state={selectedIndex:"Location",
                data:{
                   cities: ["Location","Bangalore","Chennai","Pune"] 

               } 
             };

   this.handleChangeSelection = this.handleChangeSelection.bind(this);
  //this.subscribeToEvents = this.subscribeToEvents.bind(this);
 }
 getInitialState()
 {
 
     
 }


 handleChangeSelection(evt,evtKey)
 {
    console.log("selection Change",evtKey);
  //  this.index=evt;
    this.setState({selectedIndex:evt});
    
    
 }

 componentDidMount()
 {
  console.log(" Component Mounted ");
  // document.body.addEventListener('click', this.subscribeToEvents);
    // $(document).on('click','.dropdown menu li a',this.subscribeToEvents);
 }

 subscribeToEvents(event)
 {
  console.log(" Subscribe to events");
     
  this.setState({selectedIndex : event});


 }

  render()
  {
    var titleVal = this.state.selectedIndex;
    
    
    return(
      <div class="dropdown">
         <button class="btn btn-primary dropdown-toggle" id="locationDropDown"   type="button" data-toggle="dropdown">{titleVal}
         <span class="caret"></span></button>
         <ul class="dropdown-menu">
           {  this.state.data.cities.map(function(city) {
                if(city !='Location')
                {
                  return <li onClick={this.subscribeToEvents.bind(null,city)} ><a href="#" >{city}</a></li>
                }
             })
            }
         </ul>   
      </div>);

  }
}
