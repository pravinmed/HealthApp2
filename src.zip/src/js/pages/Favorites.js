import React from "react";

export default class Archives extends React.Component {
  render() {
    return (
    	<div> One Health </div>
    
      
    );
  }
}
