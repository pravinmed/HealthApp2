import React from "react";
import { Link } from "react-router";

import Footer from "../components/layout/Footer";
import Nav from "../components/layout/Nav";

export default class Layout extends React.Component {
  LogInfo()
  {
    console.log(this.props.children);
  }
  render() {
    const { location } = this.props;
    const containerStyle = {
      marginTop: "60px" 
    };

    return (
      <div>

        <Nav location={location} />

        <div class="container" style={containerStyle}>
          <div class="row">
            <div class="col-sm-1 sideNav nav-left"> <h3> Filters Here </h3></div>
            <div class="col-sm-10">

              {this.props.children}
              {this.LogInfo()}

            </div>
            <div class="col-sm-1"><h1> Ads Here </h1> </div>
          </div>
         
        </div>
      <Footer/>
      </div>
   
    );
  }
}
