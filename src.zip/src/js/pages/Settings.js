import React from "react";

export default class Settings extends React.Component {
  render() {
    return (
      <div>
        <h1>Settings</h1>
      </div>
    );
  }
}
